import os
import matplotlib
matplotlib.use('Agg')
from mobiface.experiments import ExperimentMobiFace

if __name__ == '__main__':
    # setup experiments
    experiments = [
        ExperimentMobiFace('/home/yiming/projects/mobiface_v2019.05.02.01/mobiface80/'),
        ExperimentMobiFace('/home/yiming/projects/mobiface_v2019.05.02.01/mobiface80/', 'test')
    ]
 
    # setup trackers
    # tracker_names = ['ATOM', 'ECO', 'SiamFC', 'DaSiamRPN', 'MDNet']
    # tracker_names = ['ATOM', 'ECO', 'SiamFC', 'DaSiamRPN', 'MDNet']

    # report performance
    for e in experiments:
        tracker_names = os.listdir(e.result_dir)
        e.report(tracker_names, 'figures', show_speed=True)
